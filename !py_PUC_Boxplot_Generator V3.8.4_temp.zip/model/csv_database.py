from __future__ import annotations
from typing import List, Callable
from collections import OrderedDict
import pandas as pd
import numpy as np
from pandas import DataFrame
from os import path
import pandas.errors # Import pandas.errors


# Module to store database
class CSV_Database():

    DATASET_ID_COLUMN_NAME: str = "DATA_FILENAME"

    # Attributes
    def __init__(self) -> None:
        self._csv_data: DataFrame = DataFrame(data=None)

    @property
    def size(self) -> tuple[int, int]:
        return len(self._csv_data.index), len(self._csv_data.columns)

    @property
    def data(self) -> DataFrame:
        return self._csv_data

    @property
    def groupnames(self) -> List[str]:
        return self._csv_data[self.DATASET_ID_COLUMN_NAME].unique()

    def export_to_local(self, output_dir) -> None:
        if self._csv_data.empty:
            return
        else:
            try:
                self._csv_data.to_csv(output_dir + "\\" + "merged data.csv",
                                      header=True,
                                      index=False,
                                      sep=",",
                                      compression=None)
            except Exception as e:
                print(str(e))

    def import_csv_files(
            self,
            filepaths: str,
            reading_cols: List[str],
            skip_rows: List[int],
            callbackMessage: Callable[[str], None]
            ) -> DataFrame:
        """
        Imports data from CSV files, processes the data, and returns the count of imported files. 

        Args:
            filepaths (str): The filepaths of the CSV files to be imported.
            reading_cols (List[str]): The list of columns to be read from the CSV files.
            skip_rows (List[int]): The list of rows to be skipped while reading the CSV files.
            callbackMessage (Callable[[str], None]): A callback function to send messages during the import process.

        Returns:
            DataFrame: The count of imported files.
        """

        if reading_cols is None:
            return
        
        self._csv_data = pd.DataFrame() # Khởi tạo lại self._csv_data cho mỗi lần nhập
        imported_count: int = 0
        for filepath in filepaths:
            # splitext() return (filename, extension)
            filename = path.splitext(path.basename(filepath))[0]
            callbackMessage(f"Reading file: {path.basename(filepath)}")

            df_extracted_from_file = pd.DataFrame()
            df_current_chunk = pd.DataFrame()
            found_cols: List[str] = []

            try:
                df_raw_imported = pd.read_csv(
                    filepath, index_col=None, sep=',', header=0, skiprows=skip_rows, encoding='utf-8', encoding_errors='ignore')
                columns_df_raw_imported = list(df_raw_imported.columns)
                callbackMessage(f"- {path.basename(filepath)}: Raw columns: {columns_df_raw_imported}") # Debug print
            except Exception as e:
                callbackMessage(f"Error reading file {path.basename(filepath)}: {str(e)}") # Báo cáo lỗi cụ thể
                continue

            # Tạo một DataFrame mới cho file hiện tại với tất cả các reading_cols
            # và sử dụng index của df_raw_imported để căn chỉnh dữ liệu dễ dàng hơn.
            df_extracted_from_file = pd.DataFrame(index=df_raw_imported.index.copy())
            
            for col in reading_cols:
                if col in columns_df_raw_imported:
                    df_extracted_from_file[col] = df_raw_imported[col]
                else:
                    df_extracted_from_file[col] = np.nan # Điền NaN cho các cột bị thiếu
            
            # Chuyển đổi các cột dữ liệu sang định dạng số, ép buộc lỗi thành NaN
            for col in reading_cols:
                if col in df_extracted_from_file.columns:
                    df_extracted_from_file[col] = pd.to_numeric(df_extracted_from_file[col], errors='coerce')

            # Loại bỏ các hàng mà tất cả các cột dữ liệu (reading_cols) đều là NaN
            df_extracted_from_file = df_extracted_from_file.dropna(axis=0, how='all', subset=reading_cols)
            
            # Đảm bảo chỉ mục duy nhất trước khi thêm vào total_df
            df_extracted_from_file = df_extracted_from_file.reset_index(drop=True)

            # For later use when making plot, we need to categorize the dataset by its name,...
            # by adding extra column [DATA_FILENAME] with row value is the name of file we extract data from
            if not df_extracted_from_file.empty:
                df_extracted_from_file.insert(
                    loc=0,  # insert new column as first (left-most) column
                    column=CSV_Database.DATASET_ID_COLUMN_NAME,
                    value=filename)
                
                callbackMessage(f"- {path.basename(filepath)}: Extracted columns: {list(df_extracted_from_file.columns)}, Index unique: {df_extracted_from_file.index.is_unique}") # Debug print
                # Nối trực tiếp vào self._csv_data
                if self._csv_data.empty:
                    self._csv_data = df_extracted_from_file
                else:
                    # Đảm bảo các cột được căn chỉnh trước khi nối. Các cột không trùng sẽ được điền NaN.
                    try:
                        self._csv_data = pd.concat([self._csv_data, df_extracted_from_file], axis=0, ignore_index=True)
                    except pandas.errors.InvalidIndexError:
                        pass # Chỉ bắt lỗi và không làm gì cả để tránh in traceback
                imported_count += 1
            else:
                callbackMessage(f"No plot items found or data is empty in file: {path.basename(filepath)}") # Báo cáo nếu không có dữ liệu
        callbackMessage("")

        return imported_count

    def from_column(self,
                    column: str,
                    removeNaN: bool = False,
                    sort_data_order_by: List[str] = None
                    ) -> OrderedDict[str, np.ndarray]:
        # Validation the column name to extract data exist in target database or not
        groupby_column = self.DATASET_ID_COLUMN_NAME
        data_columns = self._csv_data.columns
        dataname_list: List[str] = []
        
        # Kiểm tra xem cột groupby có tồn tại không
        if not groupby_column in data_columns:
            return None
        
        # Extract data from CSV database để lấy danh sách các file
        all_files_data = self._csv_data[[groupby_column]].drop_duplicates()
        existing_files = set(all_files_data[groupby_column])
        
        # Nếu không tìm thấy cột dữ liệu trong toàn bộ dataset
        if not column in data_columns:
            if sort_data_order_by:
                retVal = OrderedDict()
                for name in sort_data_order_by:
                    # Luôn trả về 'no_item' khi không tìm thấy cột item
                    retVal[name] = ('no_item', np.array([]))
                return retVal
            return None

        # Extract data from CSV database
        df_subset_data = self._csv_data[[groupby_column, column]]
        groups_data = df_subset_data.groupby(by=groupby_column, sort=None)
        existing_groups = set(groups_data.groups.keys())

        # filter out the group_name of data by the order of sort_data_order_by
        if sort_data_order_by != None:
            dataname_list = sort_data_order_by
        else:
            dataname_list = list(groups_data.groups.keys())

        retVal = OrderedDict()
        
        for name in dataname_list:
            if name in existing_groups:
                # get data with type 'float' intentionally
                val = groups_data.get_group(name)[column].to_numpy(dtype='float')
                
                # remove NaN value in numpy array
                if removeNaN:
                    val = val[~np.isnan(val)]
                
                # Kiểm tra nếu mảng rỗng sau khi lọc NaN
                if len(val) == 0:
                    retVal[name] = ('empty_data', np.array([]))
                else:
                    retVal[name] = ('has_data', val)
            else:
                retVal[name] = ('no_file', np.array([]))
                
        return retVal

    def get_data_by_filename(self, filename: str) -> int:
        """
        Đếm số lượng dòng dữ liệu cho một tên file cụ thể
        """
        if 'DATA_FILENAME' not in self.data.columns:
            return 0
        return len(self.data[self.data['DATA_FILENAME'] == filename])
