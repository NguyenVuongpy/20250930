from PyQt6 import QtCore, QtGui, QtWidgets

class Ui_About(object):
    def setupUi(self, About):
        About.setObjectName("About")
        About.resize(680, 660)  
        About.setWindowTitle("About")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(":/icons/icon_about.png"), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        About.setWindowIcon(icon)

        # Thiết lập style chung với màu sắc hiện đại
        About.setStyleSheet("""
            QWidget {
                background-color: #ecf0f1;
                color: #2c3e50;
                font-family: 'Segoe UI';
            }
        """)
        
        self.main_layout = QtWidgets.QVBoxLayout(About)
        self.main_layout.setSpacing(10)
        self.main_layout.setContentsMargins(15, 15, 15, 15)

        # Header container với thiết kế hiện đại hơn
        header_container = QtWidgets.QWidget()
        header_container.setFixedHeight(100)  # Tăng chiều cao
        header_container.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                        stop:0 #1f6692, stop:0.5 #3498db, stop:1 #5dade2);
                border-radius: 15px;
                margin: 5px;
            }
        """)

        # Thêm outer glow effect cho header (bóng đổ mạnh hơn)
        header_shadow = QtWidgets.QGraphicsDropShadowEffect()
        header_shadow.setBlurRadius(40)  # Tăng độ mờ
        header_shadow.setXOffset(0)
        header_shadow.setYOffset(6)  # Tăng độ dịch xuống để làm nổi bật hơn
        header_shadow.setColor(QtGui.QColor(52, 152, 219, 120))  # Tăng opacity của bóng
        header_container.setGraphicsEffect(header_shadow)

        header_layout = QtWidgets.QHBoxLayout(header_container)
        header_layout.setContentsMargins(30, 15, 30, 15)
        header_layout.setSpacing(10)

        # Icon trong header với đổ bóng
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(60, 60)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Tạo shadow effect cho icon button với độ đậm hơn
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))  # Tăng độ đậm của shadow
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set icon cho button với kích thước lớn hơn
        icon = QtGui.QIcon(":/icons/icon_about.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(60, 60))  # Tăng kích thước icon
        
        # Thêm icon button vào header layout
        header_layout.addWidget(icon_button)

        # Text container
        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(1)

        # Title & Subtitle
        title_container = QtWidgets.QVBoxLayout()
        title_label = QtWidgets.QLabel("Application Information")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QtGui.QFont("Segoe UI", 18, QtGui.QFont.Weight.Bold))
        title_label.setStyleSheet("color: white;")

        text_layout.addWidget(title_label)
        header_layout.addWidget(text_container)
        header_layout.addStretch()

        self.main_layout.addWidget(header_container)
        # Content container với hiệu ứng đổ bóng
        content_container = QtWidgets.QWidget()
        content_container.setStyleSheet("""
            QWidget {
                background-color: white;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        
        content_layout = QtWidgets.QVBoxLayout(content_container)
        content_layout.setSpacing(10)

        # Description
        desc_text = QtWidgets.QLabel(
            "<span style='font-size:18px; font-weight:bold;'>A powerful tool for creating & analyzing boxplots from CSV data:</span><br><br>"
            "• <b>Automated Boxplot Generation:</b> Quickly generate customized boxplots for clear data visualization.<br>"
            "• <b>Statistical Insights:</b> Auto-calculate and display <b>CPK</b>, <b>Sample Size</b>, and <b>Median</b> on plots.<br>"
            "• <b>Advanced Visualization:</b> Support for <b>Violin Plots</b> and raw <b>Data Points</b> for deeper insights.<br>"
            "• <b>Anomaly Detection:</b> Highlight abnormal plots (e.g., <font color='#007bff'>CPK < 1.33</font> or unusual medians).<br>"
            "• <b>Control Limits:</b> Add spec lines and detect <b>Violations</b> using robust tests.<br>"
            "• <b>Export Options:</b> Export results to <b>PowerPoint</b>, <b>Excel</b> (with CPK & summary), or <b>Heatmaps</b>.<br>"
            "• <b>CSV Tools:</b> Flexible <b>CSV Import</b> and options for <b>Splitting Files</b> by criteria."
        )
        desc_text.setWordWrap(True)
        desc_text.setStyleSheet("color: #34495e;")
        desc_text.setFont(QtGui.QFont("Segoe UI", 10))
        content_layout.addWidget(desc_text)

        self.main_layout.addWidget(content_container)


        # Info Section
        info_group = QtWidgets.QGroupBox("Personal Information")
        info_group.setStyleSheet("""
            QGroupBox {
                font-size: 18px;
                font-weight: bold;
                color: #2c3e50;
                border: 2px solid #3498db;
                border-radius: 10px;
                padding: 10px;
                margin-top: 10px;
            }
        """)
        info_layout = QtWidgets.QFormLayout()
        info_layout.setVerticalSpacing(0)

        labels = ["Version:", "Authors:", "Contact:", "Updated:"]
        values = ["3.8.5", "Do Trong Khang, Nguyen Van Vuong", "nguyenvanvuong.26.tlhp@gmail.com", "September 02, 2025 | A80-Vietnam National Day"]

        for label, value in zip(labels, values):
            lbl = QtWidgets.QLabel(label)
            lbl.setStyleSheet("color: #2c3e50; font-weight: bold; font-size: 14px;")
            
            val = QtWidgets.QLabel(value)
            val.setStyleSheet("color: #34495e; font-size: 14px;")
            
            info_layout.addRow(lbl, val)

        info_group.setLayout(info_layout)
        content_layout.addWidget(info_group)

        # OK Button
        self.btnOK_ToClose = QtWidgets.QPushButton("OK", About)
        self.btnOK_ToClose.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border-radius: 10px;
                padding: 10px 30px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:pressed {
                background-color: #2471a3;
            }
        """)
        self.btnOK_ToClose.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))

        self.main_layout.addWidget(self.btnOK_ToClose, alignment=QtCore.Qt.AlignmentFlag.AlignCenter)

        self.retranslateUi(About)
        self.btnOK_ToClose.clicked.connect(About.close)
        QtCore.QMetaObject.connectSlotsByName(About)
    def retranslateUi(self, About):
        _translate = QtCore.QCoreApplication.translate
        self.btnOK_ToClose.setToolTip(_translate("About", "Close this window"))
