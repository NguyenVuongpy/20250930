from datetime import datetime
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE_TYPE
import os
from typing import List, Callable
from controller.workstatus import Status
from controller.setting import Setting
import pandas as pd
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor


class ImageEmbedPPTX:
    IMAGE_VERTICAL_OFFSET = Inches(-0.5)  # Âm = lên cao, Dương = xuống thấp
    callbackMessageThrower: Callable[[str], None] = None
    PPTX_TEMPLATE = 'Template_Report.pptx'
    PPTX_OUTPUT_NAME = 'Report'
    FIXED_TEXT_BOX_SHAPE_HEIGHT = 0.5
    LIST_IMAGE_FILEPATHS: List[str] = Status.LIST_FIGURE_IMAGES

    """
    GRAPH AREA IN SLIDE: area to attach external image to it.
    The attached image will be centered in the area (horizontally and vertically)
    Below positioning is based on the Top, Left corner of the slide as (0, 0) coordinate
    """
    GRAPH_TOP_MARGIN = Inches(
        1.75)  # Distance from top edge of Slide to Graph area
    # Distance from bottom edge of Slide to Graph area
    GRAPH_BOT_MARGIN = Inches(0.25)
    # Distance from left edge of Slide to Graph area
    GRAPH_LEFT_MARGIN = Inches(0.15)
    # Distance from right edge of Slide to Graph area
    GRAPH_RIGHT_MARGIN = Inches(0.15)

    SLIDE_WIDTH = 0  # Initialize only, change value after loading Template file
    SLIDE_HEIGHT = 0  # Initialize only, change value after loading Template file
    GRAPH_WIDTH = 0  # Initialize only, change value after loading Template file
    GRAPH_HEIGHT = 0  # Initialize only, change value after loading Template file

    def __init__(self):
        # check file existence
        self.pptx: Presentation = None

        if not os.path.exists(self.PPTX_TEMPLATE):
            # print(f'File {self.PPTX_FILENAME} not found.')
            return
        try:
            self.pptx = Presentation(self.PPTX_TEMPLATE)
        except:
            print(f'Failed to open Template file {
                  self.PPTX_TEMPLATE} for exporting image to.')
            self.pptx = None
            return

        ImageEmbedPPTX.SLIDE_HEIGHT = self.pptx.slide_height
        ImageEmbedPPTX.SLIDE_WIDTH = self.pptx.slide_width
        ImageEmbedPPTX.GRAPH_HEIGHT = ImageEmbedPPTX.SLIDE_HEIGHT - \
            ImageEmbedPPTX.GRAPH_TOP_MARGIN - ImageEmbedPPTX.GRAPH_BOT_MARGIN
        ImageEmbedPPTX.GRAPH_WIDTH = ImageEmbedPPTX.SLIDE_WIDTH - \
            ImageEmbedPPTX.GRAPH_LEFT_MARGIN - ImageEmbedPPTX.GRAPH_RIGHT_MARGIN

    def clearAllShapes(self) -> None:
        if self.pptx is None:
            return

        for slide in self.pptx.slides:
            # Remove the old figures
            shapes = slide.shapes
            for shape in shapes:
                match shape.shape_type:
                    case MSO_SHAPE_TYPE.GROUP | MSO_SHAPE_TYPE.PICTURE | MSO_SHAPE_TYPE.TABLE:
                        shapes.element.remove(shape.element)

    @staticmethod
    def getImageScaleVal(
            from_height: int,
            from_width: int,
            to_height: int,
            to_width: int) -> float:
        # scale figure size to max fit with max_width and max_height
        width_scale = to_width / from_width
        height_scale = to_height / from_height
        final_scale = min(width_scale, height_scale)
        return final_scale

    def update_date_in_slide(self, slide):
        """Hàm này cập nhật ngày tháng và định dạng font trong slide"""
        target_prefix = "Date: "
        current_date = datetime.now().strftime("%Y.%m.%d")
        
        for shape in slide.shapes:
            if shape.has_text_frame:
                full_text = shape.text
                if target_prefix in full_text:
                    # Tìm và cập nhật ngày tháng
                    date_start = full_text.find(target_prefix) + len(target_prefix)
                    potential_date = full_text[date_start:date_start+10]
                    
                    if len(potential_date) == 10 and potential_date[4] == '.' and potential_date[7] == '.':
                        # Cập nhật text
                        new_text = full_text[:date_start] + current_date + full_text[date_start+10:]
                        shape.text = new_text
                        
                        # Cập nhật định dạng font cho toàn bộ text box
                        for paragraph in shape.text_frame.paragraphs:
                            paragraph.alignment = PP_ALIGN.RIGHT
                            for run in paragraph.runs:
                                run.font.name = 'Arial Narrow'  # Đổi font chữ
                                run.font.size = Pt(9)   # Đổi kích thước font
                                run.font.bold = False    # Tắt bold
                                run.font.color.rgb = RGBColor(0, 0, 0)  # Màu đen
                        return
                    
    def exportImages2PPTX(self, filtered_figure_titles: List[str] = None) -> None:
        if len(self.LIST_IMAGE_FILEPATHS) == 0:
            return
        if self.pptx is None:
            return
        
        # Sử dụng filtered_figure_titles nếu được cung cấp, nếu không thì đọc từ file config
        if filtered_figure_titles is not None:
            figure_titles = filtered_figure_titles
            self.callbackMessageThrower(f"Using {len(figure_titles)} filtered titles")
        else:
            try:
                selected_config = Setting.selected_figureconfig_filename
                plot_config = pd.read_csv(selected_config)
                plot_config = plot_config[plot_config['To Plot'] == 'Yes']
                figure_titles = plot_config['Figure'].unique()
                self.callbackMessageThrower(f"Read {len(figure_titles)} titles from {selected_config}")
            except Exception as e:
                self.callbackMessageThrower(f"Unable to read file {selected_config}: {str(e)}")
                return
        # Lấy slide template từ slide đầu tiên
        if len(self.pptx.slides) > 0:
            template_slide = self.pptx.slides[0]
            # Cập nhật ngày trong template slide trước khi sao chép
            self.update_date_in_slide(template_slide)
        else:
            self.callbackMessageThrower("Template has no slides")
            return

        # Xóa tất cả các slide hiện có trừ slide template
        xml_slides = self.pptx.slides._sldIdLst
        slides = list(xml_slides)
        for slide in slides[1:]:
            xml_slides.remove(slide)

        i = 0
        for img in self.LIST_IMAGE_FILEPATHS:
            # Duplicate slide template bằng cách sử dụng layout của nó
            new_slide = self.pptx.slides.add_slide(template_slide.slide_layout)
            
            # Cập nhật ngày tháng trong slide mới
            self.update_date_in_slide(new_slide)
            
            # Copy tất cả shapes từ template (trừ title)
            for shape in template_slide.shapes:
                if shape.has_text_frame and shape.text.strip().lower() == "title":
                    continue
                    
                # Copy vị trí và kích thước
                left = shape.left
                top = shape.top
                width = shape.width
                height = shape.height
                
                if shape.has_text_frame:
                    # Copy text shape
                    new_shape = new_slide.shapes.add_textbox(left, top, width, height)
                    new_shape.text_frame.text = shape.text_frame.text
                    
                    # Copy định dạng text
                    for idx, p in enumerate(shape.text_frame.paragraphs):
                        if idx < len(new_shape.text_frame.paragraphs):
                            new_p = new_shape.text_frame.paragraphs[idx]
                            new_p.alignment = p.alignment
                            if p.runs:
                                new_p.font.name = p.runs[0].font.name
                                new_p.font.size = p.runs[0].font.size
                                new_p.font.bold = p.runs[0].font.bold
                                new_p.font.italic = p.runs[0].font.italic
                
                elif hasattr(shape, 'shape_type'):
                    # Copy các shapes khác
                    if shape.shape_type == MSO_SHAPE_TYPE.AUTO_SHAPE:
                        new_shape = new_slide.shapes.add_shape(
                            shape.auto_shape_type, left, top, width, height
                        )
                        # Copy fill
                        if hasattr(shape, 'fill'):
                            if shape.fill.type is not None:
                                new_shape.fill.solid()
                                if hasattr(shape.fill.fore_color, 'rgb'):
                                    new_shape.fill.fore_color.rgb = shape.fill.fore_color.rgb
                        
                        # Copy line
                        if hasattr(shape, 'line'):
                            if hasattr(shape.line, 'color') and shape.line.color.type is not None:
                                new_shape.line.color.rgb = shape.line.color.rgb
                            if hasattr(shape.line, 'width'):
                                new_shape.line.width = shape.line.width

            # Thêm tiêu đề mới vào góc trái trên
            if i < len(figure_titles):
                title_shape = new_slide.shapes.add_textbox(
                    left=Inches(0.2),
                    top=Inches(0.2),
                    width=Inches(8),
                    height=Inches(0.4))
                title_frame = title_shape.text_frame
                title_frame.text = figure_titles[i]
                
                # Định dạng font cho tiêu đề
                title_paragraph = title_frame.paragraphs[0]
                title_paragraph.font.size = Pt(18)
                title_paragraph.font.name = 'Arial Narrow'
                title_paragraph.font.bold = True
                title_paragraph.alignment = PP_ALIGN.LEFT
                
                # Đặt margin cho text trong textbox
                title_frame.margin_left = 0
                title_frame.margin_right = 0
                title_frame.margin_top = 0
                title_frame.margin_bottom = 0

            # Thêm và căn chỉnh hình ảnh
            added_img = new_slide.shapes.add_picture(
                image_file=img, left=0, top=0)

            # resize the added image to fit Graph area
            img_scale = ImageEmbedPPTX.getImageScaleVal(
                from_height=int(added_img.height),
                from_width=int(added_img.width),
                to_height=int(ImageEmbedPPTX.GRAPH_HEIGHT),
                to_width=int(ImageEmbedPPTX.GRAPH_WIDTH))

            added_img.width = int(added_img.width * img_scale)
            added_img.height = int(added_img.height * img_scale)

            # align picture to the center horizontally and vertically
            added_img.left = int(ImageEmbedPPTX.GRAPH_LEFT_MARGIN +
                               (ImageEmbedPPTX.GRAPH_WIDTH - added_img.width) / 2)
            added_img.top = int(ImageEmbedPPTX.GRAPH_TOP_MARGIN +
                            (ImageEmbedPPTX.GRAPH_HEIGHT - added_img.height) / 2 +
                            ImageEmbedPPTX.IMAGE_VERTICAL_OFFSET)

            # Đưa hình ảnh xuống dưới cùng
            added_img.zorder = 0

            i += 1

        # Xóa slide template
        xml_slides.remove(slides[0])

        # Save the PPT
        pptx_output_file = Setting.OUTPUT_DIR + '\\' + self.PPTX_OUTPUT_NAME + '.pptx'
        try:
            self.pptx.save(pptx_output_file)
            self.callbackMessageThrower(
                f'Successfully exported Graph to file: {pptx_output_file}')
        except Exception as e:
            try:
                self.callbackMessageThrower(str(e))
            except:
                pass
            raise Exception(e)