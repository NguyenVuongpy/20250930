import os
import pandas as pd
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QTextEdit, QMessageBox, QInputDialog,
                             QPushButton, QVBoxLayout, QLabel, QFileDialog, QWidget, QSpinBox,
                             QHBoxLayout, QCheckBox, QComboBox, QDialog, QDialogButtonBox)
from PyQt6.QtCore import QTime, Qt, QUrl, QSize, pyqtSignal
from PyQt6.QtGui import QDesktopServices, QFont, QColor, QPalette, QIcon
from PyQt6.QtWidgets import QGraphicsDropShadowEffect

class ColumnDialog(QDialog):
    def __init__(self, columns, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select Column")
        self.setFixedSize(350, 150)
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        
        layout = QVBoxLayout(self)
        
        label = QLabel("Select column name to split CSV data:")
        label.setStyleSheet("font-size: 14px; color: #2c3e50;")
        layout.addWidget(label)
        
        self.combo_box = QComboBox()
        
        # Chỉ thêm 50 cột đầu tiên vào combobox
        max_columns = 50
        if len(columns) > max_columns:
            self.combo_box.addItems(columns[:max_columns])
            # Thêm tùy chọn để xem thêm nếu có nhiều hơn 50 cột
            self.combo_box.addItem(f"... and {len(columns) - max_columns} more columns")
        else:
            self.combo_box.addItems(columns)
            
        self.combo_box.setStyleSheet("""
            QComboBox {
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 8px;
                padding: 5px 10px;
                min-width: 200px;
                color: #2c3e50;
                font-size: 12px;
            }
            QComboBox:hover {
                border: 2px solid #3498db;
                background-color: #f7fbff;
            }
            QComboBox:focus {
                border: 2px solid #3498db;
                background-color: white;
            }

            /* Nút dropdown */
            QComboBox::drop-down {
                border: none;
                padding-right: 10px;
            }
            QComboBox::down-arrow {
                image: url(:/icons/icon_dropdown.png);
                width: 12px;
                height: 12px;
            }

            /* Danh sách thả xuống */
            QComboBox QAbstractItemView {
                background: white;  /* Nền trắng */
                border: 1px solid rgba(0, 0, 0, 0.2);  /* Viền đổ bóng nhẹ */
                border-radius: 6px;
                padding: 2px;
                outline: 0px;
                selection-background-color: transparent;
            }

            /* Giảm padding danh sách */
            QComboBox QAbstractItemView::item {
                font-size: 14px;
                padding: 3px 10px;
                color: #2c3e50;
                background-color: white; /* Nền trắng */
            }

            /* Hover nổi bật hơn */
            QComboBox QAbstractItemView::item:hover {
                color: white;
                background-color: #00c2c7; /* Nền xanh ngọc */
                border-radius: 4px; /* Bo góc nhẹ */
            }

            /* Mục được chọn */
            QComboBox QAbstractItemView::item:selected {
                color: white;
                background-color: #00a2b3; /* Xanh ngọc đậm hơn */
                border-radius: 4px;
            }
        """)
        layout.addWidget(self.combo_box)
        
        button_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)
        
    def get_selected_column(self):
        return self.combo_box.currentText()

class MainWindow(QMainWindow):
    splitClosed = pyqtSignal() # Thêm signal này

    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("CSV Splitter")
        self.resize(450, 550)
        self.setWindowIcon(QIcon(":/icons/icon_split.png"))

        # Set light modern theme color palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header container with gradient background
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(85)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)

        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        # Icon container with real shadow effect
        icon_label = QLabel()
        icon_label.setFixedSize(70, 70)
        # Using a placeholder icon - replace with your actual icon path
        icon_pixmap = QIcon(":/icons/icon_split.png").pixmap(65, 65)
        icon_label.setPixmap(icon_pixmap)
        icon_label.setStyleSheet("background: transparent; border-radius: 10px;")

        # Apply real shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(12)  
        shadow.setXOffset(3)  
        shadow.setYOffset(3)  
        shadow.setColor(QColor(0, 0, 0, 80))  
        icon_label.setGraphicsEffect(shadow)  

        header_layout.addWidget(icon_label)

        # Title container (title + subtitle)
        title_container = QVBoxLayout()
        title_container.setSpacing(-2)  

        title_label = QLabel("CSV Splitter")
        title_label.setFont(QFont("Segoe UI", 24, QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
        """)

        subtitle_label = QLabel("Split csv file into multiple small csv files by column")
        subtitle_label.setFont(QFont("Segoe UI", 12))
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.85); background: transparent;")
        subtitle_label.setContentsMargins(0, -5, 0, 0)  

        title_container.addWidget(title_label)
        title_container.addWidget(subtitle_label)

        header_layout.addLayout(title_container)
        header_layout.addStretch()

        main_layout.addWidget(header_container)

        # Controls container - all in one row
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 10px 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())
        
        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(15)
        
        # Start row spinbox
        start_row_layout = QHBoxLayout()
        start_row_layout.setSpacing(8)
        start_row_label = QLabel("Start Row:", self)
        start_row_label.setStyleSheet("""
            color: #2c3e50;  
            font-size: 14px;  
            font-weight: bold;  
        """)
        self.start_row_spin = QSpinBox(self)
        self.start_row_spin.setMinimum(1)
        self.start_row_spin.setValue(3)
        self.start_row_spin.setStyleSheet("""
                QSpinBox {
                    background: #ffffff;  
                    border: 1px solid #d1d9e6;  
                    border-radius: 6px;  
                    padding: 6px 10px;  
                    color: #2c3e50;  
                    font-size: 14px;  
                    min-width: 45px;  
                    min-height: 25px;  
                }

                QSpinBox:hover {
                    border-color: #5b8def;  
                }

                QSpinBox:focus {
                    border: 2px solid #4a7bec;  
                    outline: none;  
                }

                QSpinBox::up-button, QSpinBox::down-button {
                    width: 18px;  
                    border: none;  
                    background: transparent;  
                }

                QSpinBox::up-button:hover, QSpinBox::down-button:hover {
                    background: #f0f4ff;  
                    border-radius: 4px;  
                }

                QSpinBox::up-arrow, QSpinBox::down-arrow {
                    width: 15px; 
                    height: 15px;
                }

                QSpinBox::up-arrow {
                    image: url(":/icons/icon_up.png");
                }

                QSpinBox::down-arrow {
                    image: url(":/icons/icon_down.png");
                }      
        """)
        start_row_layout.addWidget(start_row_label)
        start_row_layout.addWidget(self.start_row_spin)
        controls_layout.addLayout(start_row_layout)
        
        # Vertical separator
        separator2 = QLabel("|", self)
        separator2.setStyleSheet("color: #3498db; font-size: 20px;")  
        separator2.setFixedHeight(40)  
        controls_layout.addWidget(separator2)
        
        # Checkbox
        self.check_empty_cols = QCheckBox("Only get data in\ncolumns with spec", self)
        self.check_empty_cols.setStyleSheet("""
            QCheckBox {
                color: #2c3e50;  
                font-size: 14px;  
                font-weight: bold;  
            }
            QCheckBox::indicator {
                width: 20px;  
                height: 20px;
                border: 2px solid #e0e0e0;  
                border-radius: 4px;  
                background: #f8f9fa;
            }
            QCheckBox::indicator:checked {
                background: #4b6cb7;
                border-color: #4b6cb7;
                image: url(:/icons/icon_check.png);                                                   
            }
            QCheckBox::indicator:hover {
                border-color: #4b6cb7;
            }
        """)
        controls_layout.addWidget(self.check_empty_cols)
        
        separator2 = QLabel("|", self)
        separator2.setStyleSheet("color: #3498db; font-size: 20px;")  
        separator2.setFixedHeight(40)  
        controls_layout.addWidget(separator2)
                
        # Select file button
        self.select_file_btn = QPushButton("Select CSV File")
        self.select_file_btn.setIcon(QIcon(":/icons/icon_select.png"))
        self.select_file_btn.setIconSize(QSize(65, 65))
        self.select_file_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.select_file_btn.setFixedHeight(65)
        self.select_file_btn.setMinimumWidth(180)
        self.select_file_btn.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 150px;
                max-width: 150px;
                min-height: 50px;
                max-height: 50px;
                padding-left: 15px;
                text-align: left;
                qproperty-iconSize: 26px 26px;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
                padding-left: 17px;
                padding-top: 2px;
            }
        """)
        self.select_file_btn.clicked.connect(self.select_file)
        controls_layout.addWidget(self.select_file_btn)
        
        main_layout.addWidget(controls_container)

        # Log container
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())
        
        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(8)
        
        # Log header with icon
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)
        
        log_icon = QPushButton()
        log_icon.setIcon(QIcon(":/icons/icon_log.png"))
        log_icon.setIconSize(QSize(25, 25))
        log_icon.setFixedSize(25, 25)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)
        
        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()
        
        log_layout.addWidget(log_header)
        
        # Log area
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_area)
        
        main_layout.addWidget(log_container)
        
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # Author info
        author_label = QLabel("Created by nguyenvanvuong1", self)
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("""
            color: #3498db;
            padding: 0;
            margin: 0;
        """)
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def select_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV File", "", "CSV Files (*.csv)")
        if file_path:
            self.process_file(file_path)

    def process_file(self, file_path):
        self.update_log(f"Reading file: {os.path.basename(file_path)}")
        start_row = self.start_row_spin.value()
        
        try:
            # Read just the header to get column names
            header = pd.read_csv(file_path, nrows=0)
            columns = header.columns.tolist()
            
            # Hiển thị thông báo nếu có nhiều hơn 50 cột
            if len(columns) > 50:
                self.update_log(f"File has {len(columns)} columns. Showing first 50 columns only.")
            
            # Show dropdown dialog for column selection
            dialog = ColumnDialog(columns, self)
            if dialog.exec() != QDialog.DialogCode.Accepted:
                return
                
            DATA_SPLIT_BY_COLUMNNAME = dialog.get_selected_column()
            
            # Kiểm tra xem người dùng có chọn tùy chọn "more columns" không
            if DATA_SPLIT_BY_COLUMNNAME.startswith("... and"):
                self.update_log("Please select a valid column from the first 50 columns.")
                self.show_message_box("Info", "Please select a column from the first 50 columns shown.")
                return
                
            if not DATA_SPLIT_BY_COLUMNNAME:
                return
                
            # Now read the full data
            header_rows = pd.read_csv(file_path, nrows=start_row-1)
            filedata = pd.read_csv(file_path, index_col=None, sep=',', header=0, skiprows=range(1, start_row-1))
        except Exception as e:
            self.update_log(f"Error reading file: {str(e)}")
            self.show_message_box("Error", f"Error reading file: {str(e)}")
            return


        if filedata.empty:
            self.update_log("File is empty")
            self.show_message_box("Error", "File is empty")
            return

        if DATA_SPLIT_BY_COLUMNNAME not in filedata.columns:
            self.update_log(f"Column '{DATA_SPLIT_BY_COLUMNNAME}' not found")
            self.show_message_box("Error", f"Column '{DATA_SPLIT_BY_COLUMNNAME}' not found")
            return

        # Process empty columns removal if checkbox is checked
        if self.check_empty_cols.isChecked():
            try:
                # Read rows 2 and 3
                second_and_third_rows = pd.read_csv(file_path, skiprows=0, nrows=2)
                split_col_index = filedata.columns.get_loc(DATA_SPLIT_BY_COLUMNNAME)
                cols_to_drop = []
                
                # Check columns from split column onwards
                for col in filedata.columns[split_col_index+1:]:
                    # Check both row 2 and 3 (index 0 and 1)
                    if (pd.isna(second_and_third_rows[col].iloc[0]) or second_and_third_rows[col].iloc[0] == '') and \
                       (pd.isna(second_and_third_rows[col].iloc[1]) or second_and_third_rows[col].iloc[1] == ''):
                        cols_to_drop.append(col)
                
                if cols_to_drop:
                    filedata = filedata.drop(columns=cols_to_drop)
                    header_rows = header_rows.drop(columns=cols_to_drop)
                    self.update_log(f"Removed {len(cols_to_drop)} empty columns")
            except Exception as e:
                self.update_log(f"Error processing empty columns: {str(e)}")
                self.show_message_box("Error", f"Error processing empty columns: {str(e)}")
                return

        output_dir = os.path.dirname(file_path)

        try:
            group_data = filedata.groupby(by=DATA_SPLIT_BY_COLUMNNAME, sort=None)
            for chunk_name, chunk_data in group_data:
                try:
                    output_filename = os.path.join(output_dir, f"{chunk_name}.csv")
                    final_data = pd.concat([header_rows, chunk_data], ignore_index=True)
                    final_data = final_data.drop_duplicates()
                    final_data.to_csv(output_filename, header=True, index=False, sep=",")
                    self.update_log(f"Exported {chunk_name}.csv")
                except Exception as e:
                    self.update_log(f"Error creating file {chunk_name}.csv: {str(e)}")
                    self.show_message_box("Error", f"Error creating file {chunk_name}.csv: {str(e)}")
                    continue

            self.show_message_box("Success", f"Processed file: {os.path.basename(file_path)} \nExported to: {output_dir}")
            
        except Exception as e:
            self.update_log(f"Error splitting data: {str(e)}")
            self.show_message_box("Error", f"Error splitting data: {str(e)}")

    def update_log(self, text):
        current_time = QTime.currentTime().toString()
        self.log_area.append(f"{current_time}: {text}")
        self.log_area.repaint()

    def show_message_box(self, title, message):
        QMessageBox.information(self, title, message)

    def closeEvent(self, event):
        self.splitClosed.emit()
        super().closeEvent(event)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec())